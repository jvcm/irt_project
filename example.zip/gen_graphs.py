import pandas as pd 
import numpy as np 
import matplotlib.pyplot as plt 

def beta_irt(thetai, deltaj, aj):
    p1 = ((deltaj)/(1 - deltaj))** aj
    p2 = ((thetai)/(1 - thetai))** -aj
    den = 1 + p1 * p2
    return 1/den

def main():
    ##### PARAMETERS #####
    params_i = np.array([[0.7, 1.2], 
                       [0.3, 0.9],
                       [0.5, -0.5]])

    ##### RESPONSES #####
    responses_ij  = np.array([[0.3, 0.6, 0.7],
                            [0.4, 0.65, 0.8],
                            [0.7, 0.4, 0.3]])

    ##### ABILITIES #####
    abilities_j = np.array([0.3, 0.5, 0.7])
    
    ##### UNIFORMELY DISTRIBUTED ABILITIES (0,1) #####
    ab_lins = np.linspace(0.0001, 1, num = 300)

    fig, ax = plt.subplots(nrows=1, ncols=3, figsize=(14,4))
    for i, param in enumerate(params_i):
        exp_responses = []
        for ab in ab_lins:
            exp_responses.append(beta_irt(thetai = ab,\
                                          deltaj = param[0],\
                                          aj = param[1]))
            
        # Plot response curves
        ax[i].plot(ab_lins, exp_responses)
        ax[i].scatter(abilities_j, responses_ij[i])
        ax[i].set_xlabel('Ability')
        ax[i].set_ylabel('Response')
        ax[i].set_title('Instace {}'.format(i))
    fig.savefig('./example.png')


    return 

if __name__ == "__main__":
    main()